#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_find_cli.sh"
CLI="$(find_stm32_cli)"
IMG="${SCRIPT_DIR}/images"
sn_option=""
[[ $# -eq 1 ]] && sn_option="sn=$1"
BOOT_ADDR=0xc00e000
SLOT0=0xc038000
SLOT1=0xc088000
connect="-c port=SWD ap=1 ${sn_option} mode=HotPlug"
echo "=== H573 下载 BL2 + SPE + NS ==="
echo "BOOT_UBE=0xB4 (OEM-iRoT)"
"${CLI}" ${connect} -ob BOOT_UBE=0xB4
echo "Write Secure  ${SLOT0}"
"${CLI}" ${connect} -d "${IMG}/tfm_s_signed.bin" ${SLOT0} -v
echo "Write NS      ${SLOT1}"
"${CLI}" ${connect} -d "${IMG}/tfm_ns_signed.bin" ${SLOT1} -v
echo "Write BL2     ${BOOT_ADDR}"
"${CLI}" ${connect} -d "${IMG}/bl2.bin" ${BOOT_ADDR} -v
echo "download Done"
