STM32H573I-DK  本地 Ubuntu 烧录包（prod）
========================================

本包在服务器上由 packflash.sh 打出，拷到插着板子的 Ubuntu 即可。
不需要 TF-M 源码，不需要交叉编译器。

本机需要
--------
1) STM32CubeProgrammer（命令行 STM32_Programmer_CLI）
   装好后确认:
     which STM32_Programmer_CLI
   或存在:
     /usr/local/STMicroelectronics/STM32Cube/STM32CubeProgrammer/bin
2) USB 连 ST-Link，用户在 plugdev / dialout 组
3) 串口: /dev/ttyACM0  115200 8N1

用法
----
  chmod +x *.sh
  ./regression.sh     # 写 option bytes，会全片擦除（首次或 option bytes 乱了才跑）
  ./download.sh       # 烧 BL2 + 安全 + NS，并设 BOOT_UBE=0xB4
  ./flash_all.sh      # 上面两步一起做

替换自己编的未签名程序并重签
----------------------------
本机还需要 python3（Ubuntu: sudo apt install -y python3 python3-pip python3-venv）

  1) 包里 unsigned/ 已有本次编译的未签名 tfm_s.bin、tfm_ns.bin
     换成你自己的 bin 后执行:
  2) ./sign.sh                 # 自动签名并覆盖 images/ 里对应 signed
  3) ./download.sh             # 只烧镜像，不必再跑 regression

也可以指定文件:
  ./sign.sh unsigned/tfm_ns.bin
  ./sign.sh ns  /path/to/app.bin
  ./sign.sh s   /path/to/sapp.bin

BL2 不要用这套签；只换 S/NS。密钥是和当前板上 BL2 配套的 dummy EC-P256。

多块板子时加序列号:
  ./download.sh 002A001234

地址
----
STM32H573I-DK  烧录地址（安全别名 0x0C......）
BL2             0xc00e000   images/bl2.bin
Secure SPE      0xc038000   images/tfm_s_signed.bin
Non-Secure NS   0xc088000   images/tfm_ns_signed.bin
BOOT_UBE        0xB4  (OEM-iRoT，不要用 0xC3)
UART            ST-Link VCP  115200 8N1

注意
----
- 不要用 CubeProgrammer 再做 Full chip erase
- H5 必须 AP=1；脚本已写好
- BOOT_UBE 必须 0xB4（OEM-iRoT），不要 0xC3
- 烧完复位，NS 会跑回归测试（正式版也是可跑的 NS 测试程序）
