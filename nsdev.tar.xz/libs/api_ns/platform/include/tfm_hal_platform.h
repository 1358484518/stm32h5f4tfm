/*
 * Copyright (c) 2020-2021, Arm Limited. All rights reserved.
 * Copyright (c) 2022 Cypress Semiconductor Corporation (an Infineon company)
 * or an affiliate of Cypress Semiconductor Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 */

#ifndef __TFM_HAL_PLATFORM_H__
#define __TFM_HAL_PLATFORM_H__

#include <stddef.h>
#include <stdint.h>

#include "fih.h"
#include "tfm_hal_defs.h"
#include "cmsis_compiler.h"

/**
 * \brief Default value of the reset syndrome register that a platform can pass
 *        to \a tfm_hal_system_reset() safely. It can be overridden
 */
#ifndef TFM_PLAT_SWSYN_DEFAULT
#define TFM_PLAT_SWSYN_DEFAULT (0x0UL)
#endif /* TFM_PLAT_SWSYN_DEFAULT */

/**
 * \brief This function performs the platform-specific initialization.
 *
 * This function is called after architecture and platform common initialization
 * has finished during system early startup.
 *
 * \retval TFM_HAL_SUCCESS          Init success.
 * \retval TFM_HAL_ERROR_GENERIC    Generic errors.
 */
FIH_RET_TYPE(enum tfm_hal_status_t) tfm_hal_platform_init(void);

/**
 * \brief Get system reset syndrome. The reset syndrome is usually a register
 *        which stores the reason for the system's last reset.
 *
 * \return Returns the reset syndrome value
 */
uint32_t tfm_hal_get_reset_syndrome(void);

/**
 * \brief Clear a particular system reset syndrome bit
 *
 * \param[in] bit_pos       Bit position to clear
 */
void tfm_hal_clear_reset_syndrome_bit(uint8_t bit_pos);

/**
 * \brief System reset
 *
 * \param[in] sw_reset_syn_value  The value to be used for setting the reset
                                  syndrome register before reset happens
 */
__NO_RETURN void tfm_hal_system_reset(uint32_t sw_reset_syn_value);

/**
 * \brief System halt
 */
__NO_RETURN void tfm_hal_system_halt(void);

/**
 * \brief Set up the RNG for use with random delays.
 *
 * \retval TFM_HAL_SUCCESS        Platform specific random number generation
 *                                initialization succeeded.
 * \retval Other code             Initialization failed.
 */
int32_t tfm_hal_random_init(void);

/**
 * \brief Get a random number from an RNG seeded with an entropy source.
 *
 * \param[out] rand               Buffer to hold the random value
 * \param[in] size                The size of the buffer
 *
 * \retval TFM_HAL_SUCCESS        Platform specific random number generation
 *                                succeed.
 * \retval Other code             generation failed.
 */
int32_t tfm_hal_random_generate(uint8_t *rand, size_t size);

/**
 * \brief Get the VTOR value of non-secure image
 *
 * \return Returns the address where the vector table of the non-secure image
 *         is located
 */
uint32_t tfm_hal_get_ns_VTOR(void);

/**
 * \brief Get the entry point of the non-secure image
 *
 * \return Returns the address of the non-secure image entry point
 */
uint32_t tfm_hal_get_ns_entry_point(void);

#ifdef TFM_PARTITION_NS_AGENT_TZ
/**
 * \brief Get the initial address of non-secure image main stack
 *
 * \return Returns the initial non-secure MSP
 */
uint32_t tfm_hal_get_ns_MSP(void);
#endif /* TFM_PARTITION_NS_AGENT_TZ */

#endif /* __TFM_HAL_PLATFORM_H__ */
